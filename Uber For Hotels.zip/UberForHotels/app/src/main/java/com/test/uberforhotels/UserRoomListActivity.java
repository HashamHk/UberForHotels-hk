package com.test.uberforhotels;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserRoomListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_room_list);
    }
}
